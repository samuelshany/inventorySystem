<html>
    <head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
        <link rel="stylesheet" href="<?php echo e(asset('assets/css')); ?>/index.css">
        <link rel="stylesheet" href="<?php echo e(asset('assets/css')); ?>/all.min.css">
        
        <?php echo $__env->yieldContent('style'); ?>
        <title id="title"><?php echo $__env->yieldContent('title'); ?></title>
    </head>
    <body>
  


      
    <?php /**PATH C:\xampp\htdocs\inventorySystem\resources\views/layouts/employeeHeaderlogin.blade.php ENDPATH**/ ?>