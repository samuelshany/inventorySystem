
<?php $__env->startSection('content'); ?>
<?php if($mess != null): ?>
<div class="d-flex justify-content-center">
<div class="alert alert-danger w-50  text-center" role="alert">
  <?php echo e($mess); ?>

</div>
</div>
<?php endif; ?>
<div class="container">
    <div class="row">
        <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-12">
            <div class="product">
                <form action="<?php echo e(url('/sellProduct',$pro->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    
                    <div class="form-group">
                        <label >اسم العميل</label>
                        <select class="custom-select" name="client" id="inputGroupSelect01">
                        <option selected>Choose...</option>
                        <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($client->clientName); ?>"><?php echo e($client->clientName); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                   
                    <div class="form-group">
                        <label >الكمية</label>
                        <input class="form-control" type="number" name="sellamount" required placeholder="<?php echo e($pro->productAmount); ?>">
                    </div>
                    <div class="form-group">
                        <label >نسبة الخصم</label>
                        <input class="form-control" number="discound" required type="number">
                    </div>  
                    <div class="form-group">
                        <label > التاريخ</label>
                        <input class="form-control" name="date" required type="date" >
                    </div> 
            <button class="btn btn-primary ">بيع</button>
                    
                </form>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('product.employee', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inventorySystem\resources\views/product/sellProduct.blade.php ENDPATH**/ ?>