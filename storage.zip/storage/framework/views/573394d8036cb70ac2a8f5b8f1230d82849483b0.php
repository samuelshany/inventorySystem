
<?php $__env->startSection('content'); ?>
<form class="form-inline  d-flex justify-content-center mt-5" action="<?php echo e(url('/searchClient')); ?>" method="post" >
    <?php echo csrf_field(); ?>
      <input class="form-control " name="name" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-success mx-2 my-sm-0" type="submit">Search</button>
    </form>
<div class="container d-flex justify-content-right mt-5 ">
    <div class="row ">
         <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-3  ">
        <div class="productt text-right " >
        <img src="images/mofasa.jpg" class="imgg " >    
        
    
       <h2> الاسم :<?php echo e($client->clientName); ?> </h2>
       <h3>  التليفون :<?php echo e($client->clientPhone); ?> </h3>
       <h2> العنوان :<?php echo e($client->clientAddress); ?> </h2>
      
      <form class=" form-inline mx-2 my-lg-0" action="<?php echo e(url('/updateClientForm',$client->clientName)); ?>" method="post">
      <?php echo csrf_field(); ?>
            <button  class="btn btn-warning" >تعديل</button>
            </form>
            <form class="form-inline mx-2 py-2  my-lg-0" action="<?php echo e(url('/deleteClient',$client->clientName)); ?>"method="post">
                <?php echo csrf_field(); ?>
            <button class="btn btn-danger ">مسح</button>
            </form>

            </div>
       </div>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('product.employee', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inventorySystem\resources\views/client/viewClients.blade.php ENDPATH**/ ?>