
<?php $__env->startSection('content'); ?>
<div class="container w-50">
            <h1 class=" mt-3 text-center"> بيانات المنتج </h1>
            <div class="row" id="productForm">
            <div class="col-md-12">
            <div class="product">
                <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <form method="post" action="<?php echo e(url('/updateProduct',$pro->id)); ?>">
                    <?php echo csrf_field(); ?>
        <div class="form-group text-right">
            <label >اسم المنتج </label>
            <input  class="form-control" value="<?php echo e($pro->productName); ?> " type="text" name="name" id="productNameInp">
        </div>
        <div class="form-group text-right">
        <label> النوع</label>
            <select class="custom-select" value="<?php echo e($pro->productCat); ?> " name="category" id="productCatInp" aria-label="Example select with button addon">
           
                <option value="mobile">mobile</option>
                <option value="TV">TV</option>
                <option value="other">other</option>
              </select>
        </div>
        <div class="form-group text-right">
            <label >سعر الشراء</label>
            <input class="form-control" value="<?php echo e($pro->buyPrice); ?> " name="buyprice" type="text"   >
        </div>
        <div class="form-group text-right">
            <label >سعر البيع </label>
            <input class="form-control" value="<?php echo e($pro->sellPrice); ?> " name="sellprice" type="text"   >
        </div>
        <div class="form-group text-right">
            <label > الكمية </label>
            <input class="form-control" value="<?php echo e($pro->productAmount); ?>" name="amount" type="text"   >
        </div>
        <div class="form-group text-right">
            <label >الوصف</label>
            <textarea class="form-control" name="desc"  id="productDescInp"><?php echo e($pro->productDesc); ?></textarea>
        </div>
        <button  id="addbtn" class="btn btn-outline-primary align-right">تعديل منتج</button>
        </form>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
            </div>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('product.employee', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inventorySystem\resources\views/product/updateProduct.blade.php ENDPATH**/ ?>