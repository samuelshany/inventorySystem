
<?php $__env->startSection('content'); ?>
<form class="form-inline  d-flex justify-content-center mt-5" action="<?php echo e(url('/searchSupplierTransaction')); ?>" method="post" >
    <?php echo csrf_field(); ?>
      <input class="form-control " name="start" type="date"  aria-label="start" >
      <input class="form-control " name="end" type="date"  aria-label="Search">
      <button class="btn btn-outline-success mx-2 my-sm-0" type="submit">Search</button>
    </form>
<table class="table table-striped text-center ">
  <thead  style="background-color: green;">
    <tr class="">
    <th class="" scope="col">التاريخ</th>
    <th class="" scope="col">التكلفة</th>
    <th class="" scope="col">السعر</th>
    <th class="" scope="col">الكمية</th>
    <th class="" scope="col">اسم المنتج</th>
    <th class=" " scope="col">اسم المورد</th>
    </tr>
  </thead>
  <tbody>
      <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
    <td><?php echo e($transaction->date); ?></td>
    <td><?php echo e($transaction->totalPayment); ?></td>
    <td><?php echo e($transaction->price); ?></td>
    <td><?php echo e($transaction->amount); ?></td>
    <td><?php echo e($transaction->pName); ?></td>
    <th ><?php echo e($transaction->sName); ?></th>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
  </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('product.employee', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inventorySystem\resources\views/supplier/viewBuyTransactions.blade.php ENDPATH**/ ?>