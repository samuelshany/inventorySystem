
<?php $__env->startSection('content'); ?>
<div class="container w-50">
            <h1 class=" mt-3 text-center"> بيانات المورد </h1>
            <div class="row" id="productForm">
            <div class="col-md-12">
            <div class="product">
                <?php $__currentLoopData = $supplier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <form method="post" action="<?php echo e(url('/updateSupplier',$pro->id)); ?>">
                    <?php echo csrf_field(); ?>
        <div class="form-group text-right">
            <label >اسم المورد </label>
            <input  class="form-control" value="<?php echo e($pro->supplierName); ?> " type="text" name="name" id="productNameInp">
        </div>
       
        <div class="form-group text-right">
            <label > التليفون</label>
            <input class="form-control" value="<?php echo e($pro->supplierPhone); ?> " name="phone" type="text"   >
        </div>
        <div class="form-group text-right">
            <label >العنوان  </label>
            <input class="form-control" value="<?php echo e($pro->supplierAddress); ?> " name="address" type="text"   >
        </div>
        
        <button  id="addbtn" class="btn btn-outline-primary align-right">تعديل مورد</button>
        </form>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
            </div>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('product.employee', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inventorySystem\resources\views/supplier/updateSupplier.blade.php ENDPATH**/ ?>